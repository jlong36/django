from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('contact/', views.contact, name='contact'),
    path('login/', views.login, name='login'),
    path('aboutus/', views.aboutUs, name='aboutus'),
    path('privacypolicy/', views.privacyPolicy, name='privacypolicy'),
    path('pvsystems/', views.pvSystems, name='pvsystems'),
    path('sitemap/', views.siteMap, name='sitemap'),
    path('socialmedialinks/', views.socialMediaLinks, name='socialmedialinks')


]