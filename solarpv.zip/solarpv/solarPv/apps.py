from django.apps import AppConfig


class SolarpvConfig(AppConfig):
    name = 'solarPv'
