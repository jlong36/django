from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def index(request):
    return render(request, 'solarPv/index.html' )

def contact(request):
    return render(request, 'solarPv/contact.html')

def login(request):
    return render(request, 'solarPv/login.html')

def aboutUs(request):
    return render(request, 'solarPv/aboutus.html')

def privacyPolicy(request):
    return render(request, 'solarPv/privacypolicy.html')

def pvSystems(request):
    return render(request, 'solarPv/pvsystems.html')

def siteMap(request):
    return render(request, 'solarPv/sitemap.html')

def socialMediaLinks(request):
    return render(request, 'solarPv/socialmedialinks.html')